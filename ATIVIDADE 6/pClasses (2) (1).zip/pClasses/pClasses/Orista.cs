﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Management.Instrumentation;
using System.Text;
using System.Threading.Tasks;

namespace pClasses
{
    internal class Orista : Empregado
    {
        //public int MyProperty { get; set; }
    }
}
